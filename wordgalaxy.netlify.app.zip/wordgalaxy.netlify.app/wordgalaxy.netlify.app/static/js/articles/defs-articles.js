const idToArticleStyle = {
	0: "Professional",
	1: "Conversational",
	2: "Opinionated"
}

export {
	idToArticleStyle
}