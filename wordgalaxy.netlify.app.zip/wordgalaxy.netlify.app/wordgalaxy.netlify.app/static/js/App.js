import React  from 'react';
import './App.css';
import GeneratorSimple from './articles/gen-simple.js'

function App() {
	return (
		<div className="App">
			<GeneratorSimple/>
		</div>
	);
}

export default App;
